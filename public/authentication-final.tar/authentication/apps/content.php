<?php
require('views/content.phtml');
?>