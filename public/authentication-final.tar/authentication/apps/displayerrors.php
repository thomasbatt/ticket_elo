<?php
if (!empty($error))
	require('views/displayerrors.phtml');
?>