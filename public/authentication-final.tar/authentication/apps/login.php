<?php
require('views/login.phtml');
?>