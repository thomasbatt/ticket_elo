<?php
if (isset($_SESSION['id']))
	require('views/create.phtml');
?>