<?php
require('views/offline.phtml');
die();
?>