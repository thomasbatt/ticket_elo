<?php
require('views/home.phtml');
?>